import type { PluginRegistry } from "../plugin/plugin.registry";
import type { AnyQuestion, GradeInput, QuestionTypeAnswerMap } from "../types/question.types";

export type Answers = {
    [K in AnyQuestion["type"]]?: QuestionTypeAnswerMap[K];
} & Record<string, QuestionTypeAnswerMap[AnyQuestion["type"]] | undefined>;

export interface AttemptResult {
    score: number;
    breakdown: { questionId: string; earned: number; total: number }[];
}

export class AttemptService {
    constructor(
        private registry: PluginRegistry,
        private questions: AnyQuestion[]
    ) { }
    submit(answers: GradeInput): AttemptResult {
        let score = 0;
        const breakdown: AttemptResult["breakdown"] = [];
        for (const q of this.questions) {
            const answer = answers[q.id];
            if (answer === undefined) {
                breakdown.push({ questionId: q.id, earned: 0, total: q.points });
                continue;
            }
            const plugin = this.registry.getTyped(q.type);
            const type: string = plugin.type as string
            console.log(type);
            const earned = this.gradeQuestion(q, answer);
            score += earned;
            breakdown.push({
                questionId: q.id,
                earned,
                total: q.points
            });
        }
        return { score, breakdown };
    }

    private gradeQuestion<T extends AnyQuestion["type"]>(
        q: Extract<AnyQuestion, { type: T }>,
        answer: QuestionTypeAnswerMap[T]
    ) {
        const plugin = this.registry.getTyped(q.type);
        return plugin.grade(q, answer);
    }
}
